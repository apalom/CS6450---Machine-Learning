#!/bin/sh
python3 perceptrons.py
python3 hyper_parameters.py
