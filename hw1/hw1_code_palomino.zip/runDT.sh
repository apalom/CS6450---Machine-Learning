#!/bin/sh
python full_trees.py
python full_trees_GINI.py
python full_trees_CV.py